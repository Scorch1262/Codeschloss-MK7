
/** Includes **************************************************/
#include "mcc_generated_files/mcc.h"

/** Prototypen ************************************************/
void auswertung(void);
void keypad_eingabe(void);
char keypad_abfrage(void);