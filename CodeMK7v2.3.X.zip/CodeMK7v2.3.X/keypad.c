
/** Includes **************************************************/
#include "xc.h"
#include "keypad.h"
#include "command.h"

extern char loesung[5] = "1234";
extern bool new = 0;
char count = 0;
char data = 0;
char eingabe[5] = "xxxx";

/** Programm **************************************************/
void auswertung(void){
    if(0 == strncmp(eingabe, loesung, 4)){
        LED_Zu_SetLow();                            // LED_Zu OFF
        LED_Auf_SetHigh();                          // LED_Auf ON
        OUT1_SetLow();                              // OUT1 OFF
        OUT2_SetHigh();                             // OUT1 ON
        printf("\r\nZugriff Gewaehrt!\r\n");         // schreibt "Zugriff Gew�hrt!"
        
        __delay_ms(1000);                           // warte 1000ms
        LED1_SetLow();                              // "LED1" OFF
        __delay_ms(1000);                           // warte 1000ms
        LED2_SetLow();                              // "LED2" OFF
        __delay_ms(1000);                           // warte 1000ms
        LED3_SetLow();                              // "LED3" OFF
        __delay_ms(1000);                           // warte 1000ms
        LED4_SetLow();                              // "LED4" OFF
        __delay_ms(1000);                           // warte 1000ms
        printf("wieder Verschlossen\r\n");          // schreibt "wieder Verschlossen"
    }else{                                          // sonst
        LED_Zu_SetHigh();                           // LED_Zu ON
        LED_Auf_SetLow();                           // LED_Auf OFF
        OUT1_SetHigh();                             // OUT1 ON
        OUT2_SetLow();                              // OUT1 OFF
        printf("\r\nZugriff Verweigert!\r\n");      // schreibt "Zugriff Verweigert!"
        
        LED1_SetLow();                              // "LED1" OFF
        LED2_SetLow();                              // "LED2" OFF
        LED3_SetLow();                              // "LED3" OFF
        LED4_SetLow();                              // "LED4" OFF
    }                                               // 
    count = 0;                                      // "count" gleich 0
    data = 0;                                       // setzt "data" auf 0
    LED_Zu_SetHigh();                               // LED_Zu ON
    LED_Auf_SetLow();                               // LED_Auf OFF
    OUT1_SetHigh();                                 // OUT1 ON
    OUT2_SetLow();                                  // OUT1 OFF
}

void keypad_eingabe(void){                          // keypad_eingabe
    data = keypad_abfrage();                        // f�hre "keypad_abfrage" aus und schreibe das Ergebnis in "data"
    if(data != 0){                                  // wenn "data" ungleich 0 ist
        switch(data){                               // fragt "data" ab
            case '*':                               // wenn *
                count = 0;                          // "count" gleich 0
                data = 0;                           // setzt "data" auf 0
                LED1_SetLow();                      // "LED1" OFF
                LED2_SetLow();                      // "LED2" OFF
                LED3_SetLow();                      // "LED3" OFF
                LED4_SetLow();                      // "LED4" OFF
                printf("\r\nEingabe geloescht!\r\n");// schreibt "Eingabe gel�scht!"
                break;                              // Fertig

            case '#':                               // wenn #
                auswertung();                       // rufe "asuwertugn" auf
                break;                              // Fertig
                
            case 'A':                               // wenn A
                new = 1;                            // setzt "neu" auf 1
                break;                              // Fertig    
                         
            default:                                // ansonsten
                switch(count){                      // fragt "cout" ab
                    case 0:                         // wenn 0
                        eingabe[0] = data;          // kopiere "data" in "eingabe" stelle 0
                        count = 1;                  // "count" gleich 1
                        LED1_SetHigh();             // dann setz "LED1" auf ON
                        data = 0;                   // setzt "data" auf 0
                        break;                      // Fertig

                    case 1:                         // wenn 1
                        eingabe[1] = data;          // kopiere "data" in "eingabe" stelle 1
                        count = 2;                  // "count" gleich 2
                        LED2_SetHigh();             // dann setz "LED2" auf ON
                        data = 0;                   // setzt "data" auf 0
                        break;                      // Fertig

                    case 2:                         // wenn 2
                        eingabe[2] = data;          // kopiere "data" in "eingabe" stelle 2
                        count = 3;                  // "count" gleich 3
                        LED3_SetHigh();             // dann setz "LED3" auf ON
                        data = 0;                   // setzt "data" auf 0
                        break;                      // Fertig

                    case 3:                         // wenn 3
                        eingabe[3] = data;          // kopiere "data" in "eingabe" stelle 3
                        count = 4;                  // "count" gleich 4
                        LED4_SetHigh();             // dann setz "LED4" auf ON
                        data = 0;                   // setzt "data" auf 0
                        break;                      // Fertig
                }                                   //
                break;                              // Fertig
        }                                           // 
    }                                               // 
}                                                   //
        
char keypad_abfrage(void){                          // keypad_abfrage
    Zeile1_SetHigh();                               // setzt "Zeile_1" auf 1
    Zeile2_SetLow();                                // setzt "Zeile_2" auf 0
    Zeile3_SetLow();                                // setzt "Zeile_3" auf 0
    Zeile4_SetLow();                                // setzt "Zeile_4" auf 0
    if(Spalte1_GetValue() == 1){                    // wenn "Spalte 1" gleich 1
        printf("1");                                // schreibt "1" an UART
        while(Spalte1_GetValue() == 1);             // solange "Spalte 1" gleich 1 ist
        return '1';                                 // dann gib "1" zur�ck
    }                                               // 
    if(Spalte2_GetValue() == 1){                    // wenn "Spalte 2" gleich 1
        printf("2");                                // schreibt "2" an UART
        while(Spalte2_GetValue() == 1);             // solange "Spalte 2" gleich 1 ist
        return '2';                                 // dann gib "2" zur�ck
    }                                               // 
    if(Spalte3_GetValue() == 1){                    // wenn "Spalte 3" gleich 1
        printf("3");                                // schreibt "3" an UART
        while(Spalte3_GetValue() == 1);             // solange "Spalte 3" gleich 1 ist
        return '3';                                 // dann gib "3" zur�ck
    }                                               // 
    if(Spalte4_GetValue() == 1){                    // wenn "Spalte 4" gleich 1
        printf("A");                                // schreibt "A" an UART
        while(Spalte4_GetValue() == 1);             // solange "Spalte 4" gleich 1 ist
        return 'A';                                 // dann gib "A" zur�ck
    }                                               //     
    
    Zeile1_SetLow();                                // setzt "Zeile_1" auf 0
    Zeile2_SetHigh();                               // setzt "Zeile_2" auf 1
    Zeile3_SetLow();                                // setzt "Zeile_3" auf 0
    Zeile4_SetLow();                                // setzt "Zeile_4" auf 0
    if(Spalte1_GetValue() == 1){                    // wenn "Spalte 1" gleich 1
        printf("4");                                // schreibt "4" an UART
        while(Spalte1_GetValue() == 1);             // solange "Spalte 1" gleich 1 ist
        return '4';                                 // dann gib "4" zur�ck
    }                                               // 
    if(Spalte2_GetValue() == 1){                    // wenn "Spalte 2" gleich 1
        printf("5");                                // schreibt "5" an UART
        while(Spalte2_GetValue() == 1);             // solange "Spalte 2" gleich 1 ist
        return '5';                                 // dann gib "5" zur�ck
    }                                               // 
    if(Spalte3_GetValue() == 1){                    // wenn "Spalte 3" gleich 1
        printf("6");                                // schreibt "6" an UART
        while(Spalte3_GetValue() == 1);             // solange "Spalte 3" gleich 1 ist
        return '6';                                 // dann gib "6" zur�ck
    }                                               // 
    if(Spalte4_GetValue() == 1){                    // wenn "Spalte 4" gleich 1
        printf("B");                                // schreibt "B" an UART
        while(Spalte4_GetValue() == 1);             // solange "Spalte 4" gleich 1 ist
        return 'B';                                 // dann gib "B" zur�ck
    }                                               //     
    
    Zeile1_SetLow();                                // setzt "Zeile_1" auf 0
    Zeile2_SetLow();                                // setzt "Zeile_2" auf 0
    Zeile3_SetHigh();                               // setzt "Zeile_3" auf 1
    Zeile4_SetLow();                                // setzt "Zeile_4" auf 0
    if(Spalte1_GetValue() == 1){                    // wenn "Spalte 1" gleich 1
        printf("7");                                // schreibt "7" an UART
        while(Spalte1_GetValue() == 1);             // solange "Spalte 1" gleich 1 ist
        return '7';                                 // dann gib "7" zur�ck
    }                                               // 
    if(Spalte2_GetValue() == 1){                    // wenn "Spalte 2" gleich 1
        printf("8");                                // schreibt "8" an UART
        while(Spalte2_GetValue() == 1);             // solange "Spalte 2" gleich 1 ist
        return '8';                                 // dann gib "8" zur�ck
    }                                               // 
    if(Spalte3_GetValue() == 1){                    // wenn "Spalte 3" gleich 1
        printf("9");                                // schreibt "9" an UART
        while(Spalte3_GetValue() == 1);             // solange "Spalte 3" gleich 1 ist
        return '9';                                 // dann gib "9" zur�ck
    }                                               // 
    if(Spalte4_GetValue() == 1){                    // wenn "Spalte 4" gleich 1
        printf("C");                                // schreibt "C" an UART
        while(Spalte4_GetValue() == 1);             // solange "Spalte 4" gleich 1 ist
        return 'C';                                 // dann gib "C" zur�ck
    }                                               //     
    
    Zeile1_SetLow();                                // setzt "Zeile_1" auf 0
    Zeile2_SetLow();                                // setzt "Zeile_2" auf 0
    Zeile3_SetLow();                                // setzt "Zeile_3" auf 0
    Zeile4_SetHigh();                               // setzt "Zeile_4" auf 1
    if(Spalte1_GetValue() == 1){                    // wenn "Spalte 1" gleich 1
        printf("*");                                // schreibt "*" an UART
        while(Spalte1_GetValue() == 1);             // solange "Spalte 1" gleich 1 ist
        return '*';                                 // dann gib "*" zur�ck
    }                                               // 
    if(Spalte2_GetValue() == 1){                    // wenn "Spalte 2" gleich 1
        printf("0");                                // schreibt "0" an UART
        while(Spalte2_GetValue() == 1);             // solange "Spalte 2" gleich 1 ist
        return '0';                                 // dann gib "0" zur�ck
    }                                               // 
    if(Spalte3_GetValue() == 1){                    // wenn "Spalte 3" gleich 1
        printf("#");                                // schreibt "#" an UART
        while(Spalte3_GetValue() == 1);             // solange "Spalte 3" gleich 1 ist
        return '#';                                 // dann gib "#" zur�ck
    }                                               // 
    if(Spalte4_GetValue() == 1){                    // wenn "Spalte 4" gleich 1
        printf("D");                                // schreibt "D" an UART
        while(Spalte4_GetValue() == 1);             // solange "Spalte 4" gleich 1 ist
        return 'D';                                 // dann gib "D" zur�ck
    }                                               //       
}

