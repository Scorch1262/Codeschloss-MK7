/** Includes **************************************************/
#include "xc.h"
#include "keypad.h"
#include "command.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

char loesung[5];
bool new;
extern int status = 0;

#define USART_BUFFER_SIZE 35
unsigned char usart_buffer[USART_BUFFER_SIZE];
unsigned char usart_buffer_index=0;

/** Programm **************************************************/
void command_uart(void){                            // command_uart
    unsigned char rx = EUSART_Read();               // kopiert die ausgabe von "EUSART_Read" in rx
    if(rx=='\n') {                                  // wenn "rx" gleich "\n"
        usart_buffer[usart_buffer_index] = '\0';    // wenn "usart_buffer" an der Stell "usart_buffer_index" gleich "\0" ist
        usart_buffer_index = 0;                     // wenn "usart_buffer_index" gleich 0
        command_execute(usart_buffer);              // rufe "command_execute" mit "usart_buffer" auf
    }else if(rx!='\r'){                             // sonst wenn "rx" nicht "\r" ist
        usart_buffer[usart_buffer_index++] = rx;    // setzt in "usart_buffer" an der Stell "usart_buffer_index" "rx" ein
    }                                               // 
    if(usart_buffer_index==USART_BUFFER_SIZE) {     // wenn "usart_buffer_index" gleich "USART_BUFFER_SIZE" ist
        usart_buffer_index=0;                       // dann "usart_buffer_index" gleich "0"
    }                                               // 
}                                                   //

void command_execute(unsigned char *data){          // Auswertung der USART Commandos
    strncpy(loesung, data, 4);                      // schreibe "data" in "loesung"
    printf("xxxx");                                 // schreibt "xxxx"
    printf("\r\nKennwort geaendert\r\n");           // schreib "Kennwort ge�ndert"
    status = 1;                                     // setzt "status" auf 1
    data = 0;                                       // setzt "data" auf 0
}                                                   // 

void command_neues_pw(void){                        // neuens Kennwort
    if(new == 1){                                   // wenn "new" 1 ist
        printf("\r\n");                             // Leerzeichen  
        printf("\r\nKennwort Aendern");             // schreibt: "Neues Kennwort"
        printf("\r\nlaenge 4 Zeichen");             // schreibt: "laenge 4 Zeichen"
        printf("\r\nNeues Kennwort eingeben: ");    // schreibt: "Neues Kennwort eingeben: "
        while (1){                                  // Endlosschleife
            if(eusartRxCount != 0){                 // wenn "eusartRxCount" nicht 0 ist 
                command_uart();                     // dann rufe "command_uart" auf
                if(status == 1){                    // wenn "status" gleich 1 ist
                    break;                          // Fertig
                }                                   // 
            }                                       // 
        }                                           // 
    }                                               // 
    new = 0;                                        // setzt "new" auf 0
}                                                   // 



