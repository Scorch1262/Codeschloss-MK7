
/** Includes **************************************************/
#include "mcc_generated_files/mcc.h"

/** Prototypen ************************************************/
void command_uart(void);
void command_execute(unsigned char *data);
void command_neues_pw(void);