/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.78.1
        Device            :  PIC18F46K20
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.10 and above
        MPLAB 	          :  MPLAB X 5.30	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set LED1 aliases
#define LED1_TRIS                 TRISAbits.TRISA0
#define LED1_LAT                  LATAbits.LATA0
#define LED1_PORT                 PORTAbits.RA0
#define LED1_ANS                  ANSELbits.ANS0
#define LED1_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define LED1_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define LED1_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define LED1_GetValue()           PORTAbits.RA0
#define LED1_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define LED1_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define LED1_SetAnalogMode()      do { ANSELbits.ANS0 = 1; } while(0)
#define LED1_SetDigitalMode()     do { ANSELbits.ANS0 = 0; } while(0)

// get/set LED2 aliases
#define LED2_TRIS                 TRISAbits.TRISA1
#define LED2_LAT                  LATAbits.LATA1
#define LED2_PORT                 PORTAbits.RA1
#define LED2_ANS                  ANSELbits.ANS1
#define LED2_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define LED2_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define LED2_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define LED2_GetValue()           PORTAbits.RA1
#define LED2_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define LED2_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define LED2_SetAnalogMode()      do { ANSELbits.ANS1 = 1; } while(0)
#define LED2_SetDigitalMode()     do { ANSELbits.ANS1 = 0; } while(0)

// get/set LED3 aliases
#define LED3_TRIS                 TRISAbits.TRISA2
#define LED3_LAT                  LATAbits.LATA2
#define LED3_PORT                 PORTAbits.RA2
#define LED3_ANS                  ANSELbits.ANS2
#define LED3_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define LED3_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define LED3_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define LED3_GetValue()           PORTAbits.RA2
#define LED3_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define LED3_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define LED3_SetAnalogMode()      do { ANSELbits.ANS2 = 1; } while(0)
#define LED3_SetDigitalMode()     do { ANSELbits.ANS2 = 0; } while(0)

// get/set LED4 aliases
#define LED4_TRIS                 TRISAbits.TRISA3
#define LED4_LAT                  LATAbits.LATA3
#define LED4_PORT                 PORTAbits.RA3
#define LED4_ANS                  ANSELbits.ANS3
#define LED4_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define LED4_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define LED4_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define LED4_GetValue()           PORTAbits.RA3
#define LED4_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define LED4_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define LED4_SetAnalogMode()      do { ANSELbits.ANS3 = 1; } while(0)
#define LED4_SetDigitalMode()     do { ANSELbits.ANS3 = 0; } while(0)

// get/set LED_Zu aliases
#define LED_Zu_TRIS                 TRISAbits.TRISA4
#define LED_Zu_LAT                  LATAbits.LATA4
#define LED_Zu_PORT                 PORTAbits.RA4
#define LED_Zu_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define LED_Zu_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define LED_Zu_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define LED_Zu_GetValue()           PORTAbits.RA4
#define LED_Zu_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define LED_Zu_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)

// get/set LED_Auf aliases
#define LED_Auf_TRIS                 TRISAbits.TRISA5
#define LED_Auf_LAT                  LATAbits.LATA5
#define LED_Auf_PORT                 PORTAbits.RA5
#define LED_Auf_ANS                  ANSELbits.ANS4
#define LED_Auf_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define LED_Auf_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define LED_Auf_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define LED_Auf_GetValue()           PORTAbits.RA5
#define LED_Auf_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define LED_Auf_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define LED_Auf_SetAnalogMode()      do { ANSELbits.ANS4 = 1; } while(0)
#define LED_Auf_SetDigitalMode()     do { ANSELbits.ANS4 = 0; } while(0)

// get/set OUT2 aliases
#define OUT2_TRIS                 TRISAbits.TRISA6
#define OUT2_LAT                  LATAbits.LATA6
#define OUT2_PORT                 PORTAbits.RA6
#define OUT2_SetHigh()            do { LATAbits.LATA6 = 1; } while(0)
#define OUT2_SetLow()             do { LATAbits.LATA6 = 0; } while(0)
#define OUT2_Toggle()             do { LATAbits.LATA6 = ~LATAbits.LATA6; } while(0)
#define OUT2_GetValue()           PORTAbits.RA6
#define OUT2_SetDigitalInput()    do { TRISAbits.TRISA6 = 1; } while(0)
#define OUT2_SetDigitalOutput()   do { TRISAbits.TRISA6 = 0; } while(0)

// get/set OUT1 aliases
#define OUT1_TRIS                 TRISAbits.TRISA7
#define OUT1_LAT                  LATAbits.LATA7
#define OUT1_PORT                 PORTAbits.RA7
#define OUT1_SetHigh()            do { LATAbits.LATA7 = 1; } while(0)
#define OUT1_SetLow()             do { LATAbits.LATA7 = 0; } while(0)
#define OUT1_Toggle()             do { LATAbits.LATA7 = ~LATAbits.LATA7; } while(0)
#define OUT1_GetValue()           PORTAbits.RA7
#define OUT1_SetDigitalInput()    do { TRISAbits.TRISA7 = 1; } while(0)
#define OUT1_SetDigitalOutput()   do { TRISAbits.TRISA7 = 0; } while(0)

// get/set RC6 procedures
#define RC6_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define RC6_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define RC6_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define RC6_GetValue()              PORTCbits.RC6
#define RC6_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define RC6_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)

// get/set RC7 procedures
#define RC7_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define RC7_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define RC7_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define RC7_GetValue()              PORTCbits.RC7
#define RC7_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define RC7_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)

// get/set Spalte4 aliases
#define Spalte4_TRIS                 TRISDbits.TRISD0
#define Spalte4_LAT                  LATDbits.LATD0
#define Spalte4_PORT                 PORTDbits.RD0
#define Spalte4_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define Spalte4_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define Spalte4_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define Spalte4_GetValue()           PORTDbits.RD0
#define Spalte4_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define Spalte4_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)

// get/set Spalte3 aliases
#define Spalte3_TRIS                 TRISDbits.TRISD1
#define Spalte3_LAT                  LATDbits.LATD1
#define Spalte3_PORT                 PORTDbits.RD1
#define Spalte3_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define Spalte3_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define Spalte3_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define Spalte3_GetValue()           PORTDbits.RD1
#define Spalte3_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define Spalte3_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)

// get/set Spalte2 aliases
#define Spalte2_TRIS                 TRISDbits.TRISD2
#define Spalte2_LAT                  LATDbits.LATD2
#define Spalte2_PORT                 PORTDbits.RD2
#define Spalte2_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define Spalte2_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define Spalte2_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define Spalte2_GetValue()           PORTDbits.RD2
#define Spalte2_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define Spalte2_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)

// get/set Spalte1 aliases
#define Spalte1_TRIS                 TRISDbits.TRISD3
#define Spalte1_LAT                  LATDbits.LATD3
#define Spalte1_PORT                 PORTDbits.RD3
#define Spalte1_SetHigh()            do { LATDbits.LATD3 = 1; } while(0)
#define Spalte1_SetLow()             do { LATDbits.LATD3 = 0; } while(0)
#define Spalte1_Toggle()             do { LATDbits.LATD3 = ~LATDbits.LATD3; } while(0)
#define Spalte1_GetValue()           PORTDbits.RD3
#define Spalte1_SetDigitalInput()    do { TRISDbits.TRISD3 = 1; } while(0)
#define Spalte1_SetDigitalOutput()   do { TRISDbits.TRISD3 = 0; } while(0)

// get/set Zeile4 aliases
#define Zeile4_TRIS                 TRISDbits.TRISD4
#define Zeile4_LAT                  LATDbits.LATD4
#define Zeile4_PORT                 PORTDbits.RD4
#define Zeile4_SetHigh()            do { LATDbits.LATD4 = 1; } while(0)
#define Zeile4_SetLow()             do { LATDbits.LATD4 = 0; } while(0)
#define Zeile4_Toggle()             do { LATDbits.LATD4 = ~LATDbits.LATD4; } while(0)
#define Zeile4_GetValue()           PORTDbits.RD4
#define Zeile4_SetDigitalInput()    do { TRISDbits.TRISD4 = 1; } while(0)
#define Zeile4_SetDigitalOutput()   do { TRISDbits.TRISD4 = 0; } while(0)

// get/set Zeile3 aliases
#define Zeile3_TRIS                 TRISDbits.TRISD5
#define Zeile3_LAT                  LATDbits.LATD5
#define Zeile3_PORT                 PORTDbits.RD5
#define Zeile3_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define Zeile3_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define Zeile3_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define Zeile3_GetValue()           PORTDbits.RD5
#define Zeile3_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define Zeile3_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)

// get/set Zeile2 aliases
#define Zeile2_TRIS                 TRISDbits.TRISD6
#define Zeile2_LAT                  LATDbits.LATD6
#define Zeile2_PORT                 PORTDbits.RD6
#define Zeile2_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define Zeile2_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define Zeile2_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define Zeile2_GetValue()           PORTDbits.RD6
#define Zeile2_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define Zeile2_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)

// get/set Zeile1 aliases
#define Zeile1_TRIS                 TRISDbits.TRISD7
#define Zeile1_LAT                  LATDbits.LATD7
#define Zeile1_PORT                 PORTDbits.RD7
#define Zeile1_SetHigh()            do { LATDbits.LATD7 = 1; } while(0)
#define Zeile1_SetLow()             do { LATDbits.LATD7 = 0; } while(0)
#define Zeile1_Toggle()             do { LATDbits.LATD7 = ~LATDbits.LATD7; } while(0)
#define Zeile1_GetValue()           PORTDbits.RD7
#define Zeile1_SetDigitalInput()    do { TRISDbits.TRISD7 = 1; } while(0)
#define Zeile1_SetDigitalOutput()   do { TRISDbits.TRISD7 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/